import base_qb
import pulldata_qb

Ayush= pulldata_qb.Quickbook_customer()          #sample to get data from customer endpoint
Ayush.To_Json()
Ayush.PrintData("zero")


