Ayush=pulldata_qb.Quickbook_customer()
Ayush.To_Json()
Ayush.PrintData("zero")